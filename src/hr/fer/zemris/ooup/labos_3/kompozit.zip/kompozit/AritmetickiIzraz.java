package hr.fer.zemris.ooup.labos_3.kompozit;

public abstract class AritmetickiIzraz {

	public abstract Konstanta evaluate();

}
